//
//  Authorization.swift
//  VOB
//
//  Created by Student on 04.04.2022.
//

import UIKit

class Authorization: UIViewController {

    @IBOutlet weak var EnterBT1: UIButton!
    @IBOutlet weak var RepeatPTF: UITextField!
    @IBOutlet weak var PasswordTF: UITextField!
    @IBOutlet weak var EmailTF: UITextField!
    @IBOutlet weak var PhoneTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        PhoneTF.placeholder = "Phone"
        PhoneTF.layer.cornerRadius = 3
        EmailTF.placeholder = "Email"
        EmailTF.layer.cornerRadius = 3
        PasswordTF.placeholder = "Password"
        PasswordTF.layer.cornerRadius = 3
        RepeatPTF.placeholder = "Repeat password"
        RepeatPTF.layer.cornerRadius = 3
        EnterBT1.layer.cornerRadius = 3
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
