//
//  ViewController.swift
//  VOB
//
//  Created by Student on 04.04.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var SearchBT: UIButton!
    @IBOutlet weak var HotelsBt: UIButton!
    @IBOutlet weak var ToursBT: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ToursBT.layer.cornerRadius = 3
        HotelsBt.layer.cornerRadius = 3
        SearchBT.layer.cornerRadius = 3
        
    }


}

