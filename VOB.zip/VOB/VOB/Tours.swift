//
//  Tours.swift
//  VOB
//
//  Created by Student on 04.04.2022.
//

import UIKit

class Tours: UIViewController {

    @IBOutlet weak var BookBT: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        BookBT.layer.cornerRadius = 3
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
