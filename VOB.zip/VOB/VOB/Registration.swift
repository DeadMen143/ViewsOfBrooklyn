//
//  Registration.swift
//  VOB
//
//  Created by Student on 04.04.2022.
//

import UIKit

class Registration: UIViewController {

    @IBOutlet weak var RegBT: UIButton!
    @IBOutlet weak var EnBT: UIButton!
    @IBOutlet weak var PassTF: UITextField!
    @IBOutlet weak var PhoneTF1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        PhoneTF1.placeholder = "Phone"
        PhoneTF1.layer.cornerRadius = 3
        PassTF.placeholder = "Password"
        PassTF.layer.cornerRadius = 3
        EnBT.layer.cornerRadius = 3
        RegBT.layer.cornerRadius = 3
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
